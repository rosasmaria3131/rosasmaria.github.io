<?php
$servername="localhost";
$username="root";
$password="";
$database="dbresbakuna";
//Create connection
$conn= new mysqli($servername,$username,$password,$database) or die("Unable to connect to server");

?>