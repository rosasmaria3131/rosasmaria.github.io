-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2022 at 03:00 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbresbakuna`
--
CREATE DATABASE IF NOT EXISTS `dbresbakuna` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `dbresbakuna`;
-- --------------------------------------------------------

--
-- Table structure for table `tblsched`
--

CREATE TABLE `tblsched` (
  `SchedNumber` int(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Contact_Number` bigint(11) NOT NULL,
  `Schedule` date NOT NULL,
  `Vaccine` varchar(100) NOT NULL,
  `Dose` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsched`
--

INSERT INTO `tblsched` (`SchedNumber`, `Name`, `Address`, `Gender`, `Contact_Number`, `Schedule`, `Vaccine`, `Dose`) VALUES
(2, 'Rosemarie Sumaoang', 'Pinpinas, Santa Ignacia, Tarlac', 'Female', 9504184355, '2022-01-29', 'Pfizer', 'Booster'),
(10, 'Gerald Felipe', 'Malacampa, Camiling, Tarlac', 'Male', 9000000000, '2022-01-21', 'AstraZeneca', 'Second'),
(14, 'Richard Luis Rico', 'Tarlac, Tarlac', 'Male', 9000000000, '2022-01-22', 'JNJ', 'Second'),
(18, 'Shen Lyka Garidan', 'Tarlac', 'Male', 9504184355, '2022-01-22', 'Sinovac', 'First'),
(19, 'Rosemarie Sumaoang', 'Purok 4, Pinpinas, Santa Ignacia, Tarlac', 'Female', 9504184355, '2022-02-06', 'Moderna', 'First');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `Full_Name` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`Full_Name`, `Username`, `Password`) VALUES
('Rosemarie Domingo Sumaoang', 'Rosemarie', 'marie'),
('Shen Lyka Garidan', 'Shen', 'lyka');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblsched`
--
ALTER TABLE `tblsched`
  ADD PRIMARY KEY (`SchedNumber`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`Username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblsched`
--
ALTER TABLE `tblsched`
  MODIFY `SchedNumber` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
